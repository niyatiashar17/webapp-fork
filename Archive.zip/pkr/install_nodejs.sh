#!/bin/bash
sudo dnf module install nodejs:18/common -y
